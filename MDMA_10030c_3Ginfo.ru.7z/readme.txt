MDMA - a Mobile Data Monitoring Application
===========================================

Before running MDMA make sure you have no other applications or dashboards open that might be using your data device's communications port.
Many dashboard applications drop the connection when you close them; you can use Ctrl-Alt-Del to pop up the Windows Task Manager, select the dashboard application and click on the End Task button, and your internet connection will remain open.  When you are finished with MDMA you can close it without dropping your connection and open your dashboard again.  Doing this will keep your data counters running.  You can use your dashboard application or MDMA to keep track of your usage, but not both.  Be sure to disconnect your internet connection from the program in which you wish to track your usage.
Most dashboard applications use the autorun mechanism to start their dashboard when the modem is inserted, to temporarily stop this behaviour, hold the Shift key down while inserting the modem.  For a more permanent fix, you can disable autorun in your registry or prevent the emulated CD-ROM from being assigned a drive letter in Disk Management.
Additionally, some recent dashboards also install a service that starts their dashboard, simply disable thse services to prevent his behaviour.  Service names to look out for are 'DCservice.exe', 'Vodafone Mobile Broadband Service' and 'UI Assistant Service'.


Signal group
============
On the left is the Received Signal Strength Indicator (RSSI) in dBm, measured between -113dBm and -51dBm.
Next is your operator's Mobile Country Code (MCC) and Mobile Network Code (MNC).
Next is your operator's long alphanumeric name. Depending on device and SIM card, this information might not be available.
On the right is the Radio Access Technology; GPRS, EDGE, 3G, HSDPA, HSUPA or HSD+UPA (High Speed Downlink and Uplink).
It is normal for the HSxPA indicators to only appear while data is being transmitted, while the connection is idle, 3G is displayed.
Below this is a bar graph indicating the signal strength.
The next line of information is information from the current cellular tower; the Location Area Code, the Radio Network Controller Identifier (RNC ID), the Cell Identifier and the description.

Data Counters group
===================
The data transmitted and received in the current and last session is shown here.
You can track your total usage here as well.  The totals are stored in a file called 'usage.bin' located in the 'Common AppData' folder on your computer (normally C:\Documents and Settings\All Users\Application Data\MDMA in Win2K/XP, or C:\AppData\MDMA in Vista/Win7).
The 'Reset Session' button zeroes the current session data counters and adds to the totals, useful if you want to see exactly how much bandwidth a particular operation uses.  The 'Reset Total' button zeroes the totals, you can use this when you top-up or get a new data bundle or on your contract billing day.

Data Transfer Speed group
=========================
Here you can see your current upload and download speeds as well as the highest peak recorded.  There is also a 10 second moving average which shows the average upload and download speed over the last 10 seconds.  There are reset buttons for the peaks and the averages, these do not affect the data counters.  The negotiated QoS is also indicated here; this can vary according to your data plan, your modem and even the particular tower you are connected to.

Connection Type group
=====================
Here you can switch your connection type between GPRS/EDGE Only, GPRS/EDGE Preferred, 3G Only, or 3G Preferred.  This does not reset the card and you can do this and stay online, provided you have coverage of the signal type you requested.  For example you could switch from 3G to GPRS/EDGE to capture cellular broadcasts and then switch back to 3G.  This function works much better on Huawei cards; some older Option and Novatel cards or drivers sometimes require the card and/or your computer to be restarted before you can use them again.

APN group
=========
You can view and set your default APN here, much easier than using a modem initialization string.

USSD Commands group
===================
You can enter USSD commands here, these are commands in the form *123# that are normally entered on your mobile phones's keypad.
Clicking on 'USSD Help' will display a brief listing of some USSD commands offered by South African operators.
Sending a USSD command creates a session, some USSD services are billable, when you are finished, click the End Session button.
USSD commands that don't require any further input automatically end the session, in which case the End Session remains greyed out.
You can send multiple USSD commands sepeated by commas, for example: *111#,1,6 for Vodacom pre-paid data bundle balance.
MDMA will wait for a response before sending the next command.

Cellular Broadcast Messages group
=================================
Received cellular broadcast messages such as cell info, weather reports and tower info are shown here.
Not all operators provide 3G cell broadcasts, you might need to switch your device in GPRS/EDGE Only mode to receive them.

Start/Stop Logging
==================
This function logs signal strength, connection type, LAC, Cell ID and cellular broadcast messages to a comma-seperated-values (CSV) file.  The signal strength is recorded in its raw format, as a number from 0 to 31 or 99 for no signal.  To convert this number to dBm, multiply it by 2 and subract -113.  To convert it to a percentage, multiply it by 100 and divide the result by 31. LAC and Cell IDs are recorded in hexadecimal.

Device Info
===========
This interrogates your data device and SIM card, not all devices and SIM cards provide all the information.

About
=====
Some information about the program and an SMS form.  Sending from the form will send a standard SMS to my data device on the Vodacom network in South Africa, you usual local/international SMS rate will apply.

Reset Device
============
This instructs your device to do a full reset, you should notice that the device disappears from your operating system and gets detected again.  Some older cards or drivers do not recover from a full reset gracefully and require you to restart your computer before they become operational again.

Connect / Disconnect
====================
This allows you to connect and disconnect from the internet, MDMA executes 'rasphone.exe' which is part of your Windows installation, here you should select the dial-up connection created by your dashboard software, or by yourself.  When you are online the button changes to Disconnect which disconnects the card in the proper manner and reset the data counters for the current session and adds to the totals.

Command line options
====================
/? - Displays command line help

/port:COM<x> - Bypass the automatic detection of the data device and use the specified port

/commandset:<command set> - You can specify whether to use the Huawei, Option or Novatel set of commands.  You can only use this option if the port has already been specified.  If /commandset is not specified, only standard commands are used.

/hexprofiles - Displays assigned profile uplink and downlink values in raw hexadecimal format (for debugging).

/sessionlog - Keeps a log of data used per session in "\Documents and Settings\All Users\Application Data\MDMA" (Win2K/XP) or "\AppData\MDMA" (Vista).

/nopollcid - Disable Cell ID polling.

/u2diag:<x> - Send ^U2DIAG command to control device's emulated CD-ROM and Micro-SD card (Huawei only).
	values of <x> for most devices:
	0: disable CD-ROM and Micro-SD
	1: enable CD-ROM only
	255: enable CD-ROM and Micro-SD
	256: enable Micro-SD only

/ussdcode:<dcs> - Set the USSD data coding scheme: Auto (default), ASCII or PDU.
	The Huawei E160 is the only device known to require PDU mode so far.
	In Auto mode, MDMA will first try sending in ASCII mode and then switch to PDU mode.

/unlock:<code> - Send 6 or 8-digit network operator unlock code (Huawei only).

/opselauto - Enable automatic network operator selection and registration.
	Useful if device was set to manual operator selection by another dashboard.
